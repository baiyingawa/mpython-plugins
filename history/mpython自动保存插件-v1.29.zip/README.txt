AutoSave for mPython v1.29
===========================
mPython (基于 Blockly) 的图形化编程自动保存插件。

功能
----
- 拖拽 Blockly 积木块时自动保存（1 秒防抖）
- 仅图形化模式（.mxml），代码模式跳过
- 选择文件：通过 [浏览] 按钮选取 .mxml 文件
- 备份机制：每次保存同时写到 D:\mpython自动备份\
- 文件切换防护：检测到切换文件时自动从备份还原旧文件
- 启动提示：打开 mPython 时提示选择保存路径

安装
----
1. 确保已安装 mPython（0.8.7 或以上版本）
2. 双击运行 install.py
   - 自动查找 mPython 安装位置
   - 自动备份并修改 index.html
   - 复制 autosave.js
   - 创建 D:\mpython自动备份\ 目录
3. 启动 mPython

如果自动查找不到 mPython，脚本会提示手动输入安装路径。

卸载
----
双击运行 uninstall.py，自动还原 index.html 并删除插件文件。

文件说明
--------
autosave.js       — 插件核心（IIFE 自执行）
install.py        — 安装脚本
uninstall.py      — 卸载脚本
README.txt        — 本文件

依赖
----
- Windows 系统
- Python 3.x（安装脚本运行需要）
- mPython 0.8.7+

注意事项
--------
- 安装后首次启动顶栏会提示"请点击[浏览]选择保存路径"
- 每次启动路径为空，需重新选择（防止误保存）
- 备份目录 D:\mpython自动备份\ 需确保有写入权限
- 如果自动备份失败，检查该目录是否存在
