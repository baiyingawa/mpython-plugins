#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AutoSave for mPython v1.29 — 安装/更新脚本
===========================================
自动查找 mPython 安装位置，备份原文件，安装或更新自动保存插件。
支持保存 mPython 位置配置，后续安装/更新无需重复搜索。
"""
import os, sys, shutil, json

PACKAGE_DIR   = os.path.dirname(os.path.abspath(__file__))
CFG_FILE      = os.path.join(PACKAGE_DIR, "mpython_cfg.json")
BACKUP_DIR    = "D:/mpython自动备份"


def load_config():
    if os.path.isfile(CFG_FILE):
        try:
            with open(CFG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except: pass
    return {}


def save_config(data):
    try:
        with open(CFG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"  [!] 配置保存失败: {e}")


def find_mpython(saved_root=None):
    """查找 mPython 安装路径，优先使用已保存的路径"""
    candidates = []

    # 优先使用已保存的路径
    if saved_root and os.path.isdir(saved_root):
        candidates.append(saved_root)

    candidates += [
        "D:/APP DATA/mPython",
        "D:/Program Files/mPython",
        "C:/Program Files/mPython",
        "C:/Program Files (x86)/mPython",
        os.environ.get("M_PYTHON_HOME", ""),
    ]

    # 注册表查找
    try:
        import winreg
        for key in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
            for subkey in [r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                           r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"]:
                try:
                    with winreg.OpenKey(key, subkey) as k:
                        i = 0
                        while True:
                            try:
                                name = winreg.EnumKey(k, i)
                                with winreg.OpenKey(k, name) as sk:
                                    try:
                                        dn = winreg.QueryValueEx(sk, "DisplayName")[0]
                                        if "mpython" in dn.lower():
                                            ip = winreg.QueryValueEx(sk, "InstallLocation")[0]
                                            if ip and os.path.isdir(ip):
                                                candidates.append(ip)
                                    except: pass
                            except OSError:
                                break
                            i += 1
                except: pass
    except ImportError:
        pass

    for c in candidates:
        if c and os.path.isdir(c):
            build = os.path.join(c, "resources", "app", "build")
            index = os.path.join(build, "index.html")
            if os.path.isfile(index):
                return c, build, index
    return None, None, None


def detect_install_state(build_dir):
    """检测是首次安装还是更新"""
    index_html  = os.path.join(build_dir, "index.html")
    index_bak   = index_html + ".backup"
    autosave_js = os.path.join(build_dir, "autosave.js")

    if os.path.isfile(autosave_js):
        if os.path.isfile(index_bak):
            # 有备份 + 有插件文件 → 正常安装状态，执行更新
            return "update"
        elif os.path.isfile(index_html):
            with open(index_html, "r", encoding="utf-8", errors="replace") as f:
                html = f.read()
            if 'autosave.js' in html:
                # 有插件引用但没有备份 → 残缺安装，修复
                return "repair"
    return "fresh"


def patch_index_html(index_path, is_update):
    """在 index.html 的 </body> 前插入 autosave.js，先备份（仅首次）"""
    if is_update:
        print("  [跳过] 更新模式，无需修改 index.html")
        return True

    backup = index_path + ".backup"
    if not os.path.isfile(backup):
        shutil.copy2(index_path, backup)
        print(f"  [备份] {index_path} → {backup}")

    with open(index_path, "r", encoding="utf-8", errors="replace") as f:
        html = f.read()

    if 'autosave.js' in html:
        print("  [跳过] autosave.js 引用已存在")
        return True

    tag = '<script src="./autosave.js"></script>'
    if '</body>' in html:
        html = html.replace('</body>', tag + '\n</body>')
    else:
        html += '\n' + tag

    with open(index_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("  [修改] index.html → 已插入 autosave.js")
    return True


def copy_plugin_files(build_dir):
    """复制插件文件到 build 目录"""
    success = True
    src = os.path.join(PACKAGE_DIR, "autosave.js")
    dst = os.path.join(build_dir, "autosave.js")
    if not os.path.isfile(src):
        print(f"  [!] 缺失文件: {src}")
        return False
    try:
        shutil.copy2(src, dst)
        size = os.path.getsize(dst)
        print(f"  ✓ autosave.js ({size}B) → {dst}")
    except Exception as e:
        print(f"  [!] 复制失败: {e}")
        success = False
    return success


def ensure_backup_dir():
    """创建备份目录"""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        print(f"  [创建] {BACKUP_DIR}")
    except Exception as e:
        print(f"  [!警告] 无法创建备份目录 {BACKUP_DIR}: {e}")
        print(f"         请手动创建，否则备份功能不可用")


def main():
    print("=" * 56)
    print("  AutoSave for mPython  v1.29  安装/更新程序")
    print("=" * 56)
    print()

    cfg = load_config()
    saved_root = cfg.get("mpython_root", "")

    # 1. 查找 mPython
    print("[1/4] 查找 mPython 安装位置...")
    if saved_root:
        print(f"  ℹ 已保存路径: {saved_root}")

    root, build_dir, index_path = find_mpython(saved_root)
    if not root:
        print("  [!] 未自动找到 mPython 安装目录")
        if saved_root:
            print(f"  已保存路径不可用: {saved_root}")
        print("  请输入 mPython 安装路径（例如 D:\\APP DATA\\mPython）")
        user = input("  路径: ").strip().strip('"').strip("'")
        if not user or not os.path.isdir(user):
            print("  [!] 路径无效，安装中止")
            input("  按 Enter 键退出...")
            sys.exit(1)
        root = user
        build_dir = os.path.join(root, "resources", "app", "build")
        index_path = os.path.join(build_dir, "index.html")
        if not os.path.isfile(index_path):
            print(f"  [!] 未找到 {index_path}，请确认路径正确")
            input("  按 Enter 键退出...")
            sys.exit(1)

    print(f"  ✓ mPython: {root}")
    print(f"  ✓ 构建目录: {build_dir}")
    print()

    # 2. 检测安装状态
    state = detect_install_state(build_dir)
    is_update = (state == "update")

    if state == "fresh":
        print(f"  检测到: 首次安装")
        print(f"  将要执行的操作:")
        print(f"    · 备份 index.html → index.html.backup")
        print(f"    · 注入 autosave.js 引用到 index.html")
        print(f"    · 复制 autosave.js 到 {build_dir}")
        print(f"    · 创建备份目录 {BACKUP_DIR}")
    elif state == "update":
        print(f"  检测到: 更新（已安装 v{cfg.get('version','?')}）")
        print(f"  将要执行的操作:")
        print(f"    · 复制新版 autosave.js 到 {build_dir}")
        print(f"    · 检查备份目录")
    elif state == "repair":
        print(f"  检测到: 修复模式（存在插件引用但缺少备份）")
        print(f"  将要执行的操作:")
        print(f"    · 备份 index.html → index.html.backup")
        print(f"    · 复制 autosave.js 到 {build_dir}")
        print(f"    · 创建备份目录 {BACKUP_DIR}")

    print()
    confirm = input("  确认执行？(Y/n): ").strip().lower()
    if confirm == 'n':
        print("  已取消。")
        input("  按 Enter 键退出...")
        sys.exit(0)
    print()

    # 3. 配置 index.html
    step_label = "[2/4]" if state == "fresh" else "[2/3]"
    print(f"{step_label} 配置 index.html...")
    patch_index_html(index_path, is_update)
    if not is_update:
        print()

    # 4. 复制插件
    step_label = "[3/4]" if state == "fresh" else "[2/3]"
    print(f"{step_label} 复制插件文件...")
    copy_plugin_files(build_dir)
    print()

    # 5. 创建备份目录
    step_label = "[4/4]" if state == "fresh" else "[3/3]"
    print(f"{step_label} 创建备份目录...")
    ensure_backup_dir()
    print()

    # 6. 保存配置
    cfg.update({
        "mpython_root": root,
        "build_dir": build_dir,
        "version": "1.28",
    })
    save_config(cfg)

    action = "更新" if is_update else "安装"
    print("=" * 56)
    print(f"  ✓ {action}成功！")
    print()
    print("  使用方法:")
    print("    1. 启动 mPython")
    print("    2. 顶栏出现 AutoSave v1.29 插件栏")
    print("    3. 点击 [浏览] 选择要保存的 .mxml 文件")
    print("    4. 编辑 Blockly 积木块时自动保存")
    print("    5. 备份文件存储在 D:\\mpython自动备份\\")
    print()
    print("  如需卸载，运行 uninstall.py")
    print("  如需更新，重新运行本脚本即可自动检测更新")
    print("=" * 56)
    print()
    input("  按 Enter 键退出...")


if __name__ == "__main__":
    main()
