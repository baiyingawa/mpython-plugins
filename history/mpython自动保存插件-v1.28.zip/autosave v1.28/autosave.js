/**
 * mPython 自动保存插件 v1.28
 * - 每次保存同时存原路径和 D:\mpython自动备份\
 * - 切换文件时自动从备份还原，防止覆盖
 * - lastFileId 单重校验保护
 */
(function() {
  'use strict';

  var AUTO_SAVE_DELAY = 1000;
  var BACKUP_INTERVAL = 5 * 60 * 1000;  // 5分钟
  var BACKUP_MAX = 100;
  var BACKUP_DIR = 'D:/mpython自动备份/';
  var saveTimer = null;
  var backupTimer = null;
  var lastSaveTime = null;
  var isSaving = false;
  var foundWorkspace = null;
  var CACHE_KEY = 'autosave_path_cache';
  var isReady = false;
  var wsSetupDone = false;
  var userSetPath = false;
  var lastFileId = null;

  // ====== 日志 ======
  var LOG = [];
  function persistLog() { try { localStorage.setItem('autosave_log', JSON.stringify(LOG.slice(-50))); } catch(e) {} }
  function addLog(level, msg) {
    LOG.push({ t: new Date(), level: level, msg: msg });
    if (LOG.length > 200) LOG.splice(0, LOG.length - 200);
    persistLog();
    if (level === 'ERR') console.error('[AutoSave]', msg);
    else if (level === 'WARN') console.warn('[AutoSave]', msg);
    else console.log('[AutoSave]', msg);
  }
  function log()   { addLog('LOG',  Array.prototype.slice.call(arguments).join(' ')); }
  function warn()  { addLog('WARN', Array.prototype.slice.call(arguments).join(' ')); }
  function err()   { addLog('ERR',  Array.prototype.slice.call(arguments).join(' ')); }

  // ====== 日志展示 ======
  window.showAutoSaveLog = function() {
    try {
      var existing = gel('autosave-log-modal');
      if (existing) { existing.style.display = 'flex'; return; }

      var overlay = document.createElement('div');
      overlay.id = 'autosave-log-modal';
      overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:100000;display:flex;align-items:center;justify-content:center;';

      var box = document.createElement('div');
      box.style.cssText = 'background:#1a1a2e;border:1px solid #0f3460;border-radius:6px;padding:14px;max-width:80%;max-height:80%;display:flex;flex-direction:column;';

      var hdr = document.createElement('div');
      hdr.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;';
      hdr.innerHTML = '<span style="color:#e94560;font-weight:bold;font-size:13px;">AutoSave 日志</span>';

      var closeBtn = document.createElement('span');
      closeBtn.textContent = '[关闭]';
      closeBtn.style.cssText = 'color:#888;font-size:12px;cursor:pointer;';
      closeBtn.onclick = function(){overlay.style.display='none';};
      hdr.appendChild(closeBtn);

      var ta = document.createElement('textarea');
      ta.readOnly = true;
      ta.style.cssText = 'background:#0d0d1a;color:#b0b0b0;border:1px solid #0f3460;border-radius:4px;padding:8px;font-size:11px;font-family:Consolas,monospace;width:580px;height:360px;resize:both;outline:none;';
      ta.value = LOG.map(function(l){return '['+l.t.toLocaleTimeString()+']['+l.level+'] '+l.msg;}).join('\n') || '(无日志)';

      box.appendChild(hdr);
      box.appendChild(ta);
      overlay.appendChild(box);
      document.body.appendChild(overlay);
      overlay.onclick = function(e){if(e.target===overlay)overlay.style.display='none';};
    } catch(e) { console.error('[AutoSave] log modal:', e); }
  };

  // ====== UI ======
  function fmt(date) { return [date.getHours().toString().padStart(2,'0'), date.getMinutes().toString().padStart(2,'0'), date.getSeconds().toString().padStart(2,'0')].join(':'); }
  function ts(date) {
    var y = date.getFullYear();
    var M = (date.getMonth()+1).toString().padStart(2,'0');
    var d = date.getDate().toString().padStart(2,'0');
    var h = date.getHours().toString().padStart(2,'0');
    var m = date.getMinutes().toString().padStart(2,'0');
    var s = date.getSeconds().toString().padStart(2,'0');
    return y + M + d + '_' + h + m + s;
  }
  var els = {};
  var rescueTimer = null;
  var barRef = null;
  var filePicker = null;

  function gel(id) { try { return document.getElementById(id); } catch(e) { return null; } }

  function refreshEls() {
    try {
      els.time   = gel('autosave-time');
      els.status = gel('autosave-status');
      els.notice = gel('autosave-notice');
    } catch(e) { err('refreshEls:', e.message); }
  }

  function getCurrentFileId() {
    try {
      var state = getState();
      if (!state) return null;
      if (state.xmlFileName) return 'mxml:' + state.xmlFileName;
      if (state.editorList) {
        for (var i = 0; i < state.editorList.length; i++) {
          if (state.editorList[i].select) return 'editor:' + (state.editorList[i].absolutePath || state.editorList[i].path || '');
        }
      }
    } catch(e) {}
    return null;
  }

  function promptSelectPath() { showNotice('请点击[浏览]选择保存路径', '#ff9800'); }

  function createFilePicker() {
    if (filePicker) return;
    try {
      filePicker = document.createElement('input');
      filePicker.type = 'file';
      filePicker.accept = '.mxml';
      filePicker.style.display = 'none';
      filePicker.id = 'autosave-file-picker';
      document.body.appendChild(filePicker);
      filePicker.addEventListener('change', function(e) {
        try {
          if (e.target.files && e.target.files[0]) {
            var fullPath = e.target.files[0].path;
            updatePathDisplay(fullPath);
            setCachedPath('mxml', fullPath, fullPath);
            userSetPath = true;
            lastFileId = getCurrentFileId();
            hideNotice();
            startBackupTimer();
            log('浏览:', fullPath);
          }
          e.target.value = '';
        } catch(ex) { err('picker:', ex.message); }
      });
    } catch(e) { err('createFilePicker:', e.message); }
  }

  function onClick(e) {
    try {
      var id = e.target && (e.target.id || '');
      if (id === 'autosave-logbtn') { window.showAutoSaveLog(); }
      else if (id === 'autosave-browse-btn') { if (filePicker) filePicker.click(); }
    } catch(ex) { err('onClick:', ex.message); }
  }

  function bindEvents(bar) {
    if (!bar) return;
    try { bar.addEventListener('click', onClick); } catch(e) { err('bindEvents:', e.message); }
  }

  function setupUI() {
    try {
      if (gel('autosave-bar')) { refreshEls(); return; }
      var bar = document.createElement('div');
      bar.id = 'autosave-bar';
      bar.style.cssText = 'position:fixed;top:0;left:0;right:0;height:28px;background:linear-gradient(90deg,#1a1a2e,#16213e);color:#e0e0e0;font-size:12px;font-family:Segoe UI,sans-serif;display:flex;align-items:center;padding:0 12px;z-index:99999;border-bottom:1px solid #0f3460;box-shadow:0 2px 4px rgba(0,0,0,0.3);';
      var pv = (getCachedPath('mxml') || {}).absolutePath || '';
      bar.innerHTML =
        '<span style="color:#e94560;font-weight:bold;font-size:13px;margin-right:2px;">AutoSave</span><span style="color:#666;font-size:9px;margin-right:10px;">by uu</span><span id="autosave-time" style="margin-right:16px;">加载中...</span>' +
        '<span id="autosave-status" style="display:none;"></span><span style="color:#888;font-size:11px;margin-left:4px;">路径:</span>' +
        '<span id="autosave-path-display" style="color:#b0b0b0;font-size:11px;margin-left:4px;flex:1;min-width:80px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+(pv||'未设置')+'</span>' +
        '<span id="autosave-browse-btn" style="color:#4ecdc4;font-size:11px;cursor:pointer;margin-left:4px;text-decoration:underline;">[浏览]</span>' +
        '<span id="autosave-notice" style="font-size:11px;display:none;margin-left:4px;"></span>' +
        '<span id="autosave-logbtn" style="color:#888;font-size:11px;cursor:pointer;margin-left:6px;">[日志]</span><span style="color:#666;font-size:11px;margin-left:4px;">v1.28</span>';
      document.body.insertBefore(bar, document.body.firstChild);
      document.body.style.marginTop = '28px';
      barRef = bar;
      refreshEls();
      createFilePicker();
      bindEvents(bar);
      if (rescueTimer) clearInterval(rescueTimer);
      rescueTimer = setInterval(function() {
        try {
          var b = gel('autosave-bar');
          if (!b) { log('重建'); rescueTimer = null; setupUI(); return; }
          refreshEls();
          if (b !== barRef) { barRef = b; bindEvents(b); }
        } catch(ex) { err('rescue:', ex.message); }
      }, 2000);
      log('v1.28');
    } catch(e) { err('setupUI:', e.message); }
  }

  function display(t, c) { try { if (els.time) { els.time.textContent = t; if (c) els.time.style.color = c; } else { refreshEls(); if (els.time) { els.time.textContent = t; if (c) els.time.style.color = c; } } } catch(e) {} }
  function showStatus(t, c) { try { if (!els.status) refreshEls(); if (!els.status) return; els.status.textContent = t; els.status.style.color = c||'#ff9800'; els.status.style.display = 'inline'; if (c==='#4caf50') setTimeout(function(){try{if(els.status)els.status.style.display='none'}catch(ex){}},5000); } catch(e) {} }
  function showNotice(t, c) { try { if (!els.notice) refreshEls(); if (!els.notice) return; els.notice.textContent = t; els.notice.style.color = c||'#ff9800'; els.notice.style.display = 'inline'; } catch(e) {} }
  function hideNotice() { try { if (els.notice) els.notice.style.display = 'none'; } catch(e) {} }
  function updatePathDisplay(v) { try { var e = gel('autosave-path-display'); if (e) e.textContent = v||'未设置'; } catch(ex) {} }

  // ====== workspace ======
  function getWorkspace() {
    try {
      if (foundWorkspace) { try { if (foundWorkspace.getTopBlocks) return foundWorkspace; } catch(e) { foundWorkspace = null; } }
      if (window.vm && window.vm.$store && window.vm.$store.state && window.vm.$store.state.workspace) {
        var ws = window.vm.$store.state.workspace;
        if (ws && ws.getTopBlocks) { foundWorkspace = ws; return ws; }
      }
      var svgs = document.querySelectorAll('svg');
      for (var i = 0; i < svgs.length; i++) { if (svgs[i].blocklyWorkspace && svgs[i].blocklyWorkspace.getTopBlocks) { foundWorkspace = svgs[i].blocklyWorkspace; return svgs[i].blocklyWorkspace; } }
    } catch(e) {}
    return null;
  }

  // ====== XML ======
  function getXML(ws) {
    try {
      if (window.vm && window.vm.$store && window.vm.$store.state && window.vm.$store.state.xmlCode) {
        var x = window.vm.$store.state.xmlCode;
        if (x && x !== '<xml xmlns="https://developers.google.com/blockly/xml"></xml>') return x;
      }
      return '<xml xmlns="https://developers.google.com/blockly/xml"></xml>';
    } catch(e) { return '<xml xmlns="https://developers.google.com/blockly/xml"></xml>'; }
  }

  // ====== 缓存 ======
  function getCachedPath(key) { try { var d = localStorage.getItem(CACHE_KEY+'_'+key); return d ? JSON.parse(d) : null; } catch(e) { return null; } }
  function setCachedPath(key, url, abs) { try { localStorage.setItem(CACHE_KEY+'_'+key, JSON.stringify({url:url,absolutePath:abs})); } catch(e) {} }
  function getState() { try { if (window.vm && window.vm.$store) return window.vm.$store.state; } catch(e) {} return null; }

  function getTargetPath() {
    try {
      var s = getState(); if (!s || s.modeSate !== 0) return null;
      var c = getCachedPath('mxml'); return (c && c.absolutePath) ? {path:c.absolutePath, modeSate:0} : null;
    } catch(e) { return null; }
  }

  // ====== 文件系统（统一用 routerDesk.saveFile）======
  function writeFile(p, c) {
    if (window.routerDesk && typeof window.routerDesk.saveFile === 'function') {
      try { window.routerDesk.saveFile({url:p, data:c, project:'project', modeSate:0, absolutePath:p}); return true; } catch(e) {}
    }
    return false;
  }
  /** 用 XMLHttpRequest 读取文件（Electron 支持 file://）
   *  注意：同步 XHR，仅用于还原备份（本地文件读取，耗时可忽略） */
  function readFileViaFetch(filePath) {
    try {
      var url = 'file:///' + filePath.replace(/\\/g, '/');
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url, false);
      xhr.overrideMimeType('text/plain;charset=utf-8');
      xhr.send();
      if (xhr.status === 0 || xhr.status === 200) return xhr.responseText;
      warn('readFile:', xhr.status, filePath);
      return null;
    } catch(e) { err('readFileViaFetch:', e.message); return null; }
  }

  // ====== 备份 ======
  function startBackupTimer() {
    if (backupTimer) clearInterval(backupTimer);
    backupTimer = setInterval(function() {
      // 快照：重命名最新备份为时间戳版（纯占位，fs不可用时跳过）
    }, BACKUP_INTERVAL);
    log('备份定时器 (5min)');
  }

  /** 每次保存时同步到备份目录 */
  function saveBackup(content, targetPath) {
    try {
      var baseName = targetPath.replace(/^.*[\\/]/, '').replace(/\.mxml$/i, '');
      var safePath = BACKUP_DIR + baseName + '_bak_main.py.mxml';
      if (window.routerDesk && typeof window.routerDesk.saveFile === 'function') {
        window.routerDesk.saveFile({
          url: safePath, data: content, project: 'project', modeSate: 0,
          absolutePath: safePath
        });
        log('备份:', 'OK', content.length+'B', '→', safePath);
      }
    } catch(e) { err('saveBackup:', e.message); }
  }

  /** 从备份还原文件 */
  function restoreFromBackup(originalPath) {
    try {
      var baseName = originalPath.replace(/^.*[\\/]/, '').replace(/\.mxml$/i, '');
      var bakPath = BACKUP_DIR + baseName + '_bak_main.py.mxml';
      var restoreData = readFileViaFetch(bakPath);
      if (restoreData && window.routerDesk && typeof window.routerDesk.saveFile === 'function') {
        window.routerDesk.saveFile({url:originalPath, data:restoreData, project:'project', modeSate:0, absolutePath:originalPath});
        log('还原:', originalPath);
      }
    } catch(e) { err('restore:', e.message); }
  }

  /** 清除保存状态 + 还原备份 */
  function clearSaveState() {
    // 在清除前还原
    var cached = getCachedPath('mxml');
    if (cached && cached.absolutePath) restoreFromBackup(cached.absolutePath);

    userSetPath = false;
    try { localStorage.removeItem(CACHE_KEY + '_mxml'); } catch(ex) {}
    updatePathDisplay('');
    if (backupTimer) { clearInterval(backupTimer); backupTimer = null; }
    promptSelectPath();
  }

  // ====== 保存 ======
  function silentSave(target) {
    if (!target || target.modeSate !== 0) return false;
    try {
      var ws = getWorkspace(); if (!ws) return false;
      var content = getXML(ws);
      if (!content || content.length < 15) { warn('XML过短:', (content||'').length); return false; }

      var now = new Date();
      var since = lastSaveTime ? Math.round((now - lastSaveTime)/1000) + 's' : '首次';
      var blocks = 0;
      try { var bs = ws.getTopBlocks(true); blocks = bs ? bs.length : 0; } catch(ex) {}

      content = '<!--mPythonType:0-->\r\n' + content;

      var params = { url: target.path, data: content, project: 'project', modeSate: 0 };
      if (target.path.match(/^[a-zA-Z]:\\|^[a-zA-Z]:\/|^\/|^\\\\/)) params.absolutePath = target.path;
      log('保存:', content.length+'B', blocks+'块', '距上次'+since, '→', target.path);

      saveBackup(content, target.path);

      if (window.routerDesk && typeof window.routerDesk.saveFile === 'function') {
        var result = window.routerDesk.saveFile(params);
        if (result && typeof result.then === 'function') {
          result.then(function() { saveOK(); }).catch(function() { saveOK(); });
        } else { saveOK(); }
        return true;
      }
    } catch(e) { warn('保存失败:', e.message); }
    return false;
  }

  function doSave() {
    if (isSaving || !isReady) return;
    var state = getState();
    if (state && state.modeSate !== 0) { log('跳过: 代码模式'); return; }

    var currentId = getCurrentFileId();
    if (lastFileId !== null && currentId !== null && lastFileId !== currentId) {
      log('防护拦截: lastId='+lastFileId+' curId='+currentId);
      clearSaveState();
      return;
    }

    var ws = getWorkspace();
    var blocks = 0;
    try { var bs = ws.getTopBlocks(true); blocks = bs ? bs.length : 0; } catch(ex) {}
    log('触发保存: blocks='+blocks, 'fileId='+(currentId||'?'));

    var target = getTargetPath();
    if (!target) { log('跳过: 无路径'); return; }
    isSaving = true;
    if (silentSave(target)) { isSaving = false; return; }
    isSaving = false;
  }

  function saveOK() {
    lastSaveTime = new Date();
    display('上次保存: ' + fmt(lastSaveTime), '#4caf50');
  }
  function trigger() { if (saveTimer) clearTimeout(saveTimer); saveTimer = setTimeout(doSave, AUTO_SAVE_DELAY); }

  function checkFileChanged() {
    var cur = getCurrentFileId();
    if (!cur) return false;
    if (lastFileId === null) { lastFileId = cur; return false; }
    if (lastFileId !== cur) {
      log('文件切换:', lastFileId, '->', cur);
      lastFileId = cur;
      clearSaveState();
      return true;
    }
    return false;
  }

  function startPathWatcher() {
    setInterval(function() {
      try {
        checkFileChanged();
        if (isReady && !getCachedPath('mxml') && !userSetPath) promptSelectPath();
      } catch(e) {}
    }, 3000);
  }

  function startReadyCheck(ws) {
    var minDelay = 5000, maxDelay = 15000, startedAt = Date.now();
    var lastCount = -1, stableCount = 0;
    setTimeout(function() {
      if (!isReady) { isReady = true; display('已连接', '#4caf50'); log('5s就绪'); if (!getCachedPath('mxml') && !userSetPath) promptSelectPath(); }
    }, minDelay);
    function check() {
      var e = Date.now() - startedAt; var b = 0;
      try { var bs = ws.getTopBlocks(true); b = bs ? bs.length : 0; } catch(ex) {}
      if (b === lastCount) stableCount++; else { stableCount = 0; lastCount = b; }
      if (isReady || (e >= minDelay && stableCount >= 2) || e >= maxDelay) {
        if (!isReady) { isReady = true; display('就绪('+Math.round(e/1000)+'s,'+b+'块)', '#4caf50'); log('就绪'); if (!getCachedPath('mxml') && !userSetPath) promptSelectPath(); }
        return;
      }
      display('加载...('+Math.round(e/1000)+'s,'+b+'块)', '#ff9800');
      setTimeout(check, 1000);
    }
    setTimeout(check, 1000);
  }

  function doSetup(ws) {
    if (wsSetupDone) return;
    wsSetupDone = true;
    foundWorkspace = ws;
    if (ws.addChangeListener) ws.addChangeListener(function(e) { if (e && e.type === 'ui') return; trigger(); });
    var blocks = 0;
    try { var bs = ws.getTopBlocks(true); blocks = bs ? bs.length : 0; } catch(ex) {}
    log('setup: blocks='+blocks, 'changeListener OK');
    startReadyCheck(ws);
  }

  function init() {
    try {
      try { localStorage.removeItem(CACHE_KEY+'_mxml'); } catch(ex) {}
      userSetPath = false;
      setupUI();
      log('v1.28启动');
      var state = getState();
      log('API: vm='+!!window.vm, 'rD='+(typeof window.routerDesk), 'store='+(state?'有':'无'));
      startPathWatcher();
      var ws = getWorkspace();
      if (ws) { display('detect ws', '#ff9800'); doSetup(ws); return; }
      log('wait ws...');
      new MutationObserver(function() { if (!foundWorkspace) { var w = getWorkspace(); if (w) doSetup(w); } }).observe(document.body, {childList:true,subtree:true});
      var cnt = 0, tmr = setInterval(function() {
        cnt++;
        if (foundWorkspace) { clearInterval(tmr); return; }
        var w = getWorkspace();
        if (w) { display('ok('+cnt+'s)', '#4caf50'); doSetup(w); clearInterval(tmr); return; }
        if (cnt <= 5) display('启动('+cnt+'s)', '#ff9800');
        else if (cnt <= 10) display('等待('+cnt+'s)...', '#ff9800');
        else if (!isReady) { isReady = true; display('备用模式', '#4caf50'); log(cnt+'s备用'); if (!getCachedPath('mxml') && !userSetPath) promptSelectPath(); }
      }, 1000);
    } catch(e) { err('init:', e.message); }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() { setTimeout(init, 300); });
  } else { setTimeout(init, 300); }

})();
