#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AutoSave for mPython v1.28 — 安装脚本
====================================
自动查找 mPython 安装位置，备份原文件，安装自动保存插件。
"""

import os, sys, shutil, glob, json, re

PACKAGE_DIR   = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR    = "D:/mpython自动备份"

FILES_TO_COPY = [
    ("autosave.js",    "build/autosave.js"),
]

def find_mpython():
    """尝试查找 mPython 安装路径"""
    candidates = [
        "D:/APP DATA/mPython",
        "D:/Program Files/mPython",
        "C:/Program Files/mPython",
        "C:/Program Files (x86)/mPython",
        os.environ.get("M_PYTHON_HOME", ""),
    ]
    # 注册表查找（仅 Windows）
    try:
        import winreg
        for key in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
            for subkey in [r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                           r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"]:
                try:
                    with winreg.OpenKey(key, subkey) as k:
                        i = 0
                        while True:
                            try:
                                name = winreg.EnumKey(k, i)
                                with winreg.OpenKey(k, name) as sk:
                                    try:
                                        dn = winreg.QueryValueEx(sk, "DisplayName")[0]
                                        if "mpython" in dn.lower():
                                            ip = winreg.QueryValueEx(sk, "InstallLocation")[0]
                                            if ip and os.path.isdir(ip):
                                                candidates.append(ip)
                                    except: pass
                            except OSError:
                                break
                            i += 1
                except: pass
    except ImportError:
        pass

    for c in candidates:
        if c and os.path.isdir(c):
            build = os.path.join(c, "resources", "app", "build")
            index = os.path.join(build, "index.html")
            if os.path.isfile(index):
                return c, build, index
    return None, None, None

def patch_index_html(index_path):
    """在 index.html 的 </body> 前插入 autosave.js，先备份"""
    backup = index_path + ".backup"
    if not os.path.isfile(backup):
        shutil.copy2(index_path, backup)
        print(f"  [备份] {index_path} → {backup}")

    with open(index_path, "r", encoding="utf-8", errors="replace") as f:
        html = f.read()

    if 'autosave.js' in html:
        print("  [跳过] autosave.js 已存在 index.html 中")
        return True

    # 在 </body> 前插入
    tag = '<script src="./autosave.js"></script>'
    if '</body>' in html:
        html = html.replace('</body>', tag + '\n</body>')
    else:
        html += '\n' + tag

    with open(index_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("  [修改] index.html → 已插入 autosave.js")
    return True

def ensure_backup_dir():
    """创建备份目录"""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        print(f"  [创建] {BACKUP_DIR}")
    except Exception as e:
        print(f"  [!警告] 无法创建备份目录 {BACKUP_DIR}: {e}")
        print(f"         请手动创建，否则备份功能不可用")

def main():
    print("=" * 56)
    print("  AutoSave for mPython  v1.28  安装程序")
    print("=" * 56)
    print()

    # 1. 查找 mPython
    print("[1/4] 查找 mPython 安装位置...")
    root, build_dir, index_path = find_mpython()
    if not root:
        print("  [!] 未自动找到 mPython 安装目录")
        print("  请输入 mPython 安装路径（例如 D:\\APP DATA\\mPython）")
        user = input("  路径: ").strip().strip('"').strip("'")
        if not user or not os.path.isdir(user):
            print("  [!] 路径无效，安装中止")
            sys.exit(1)
        root = user
        build_dir = os.path.join(root, "resources", "app", "build")
        index_path = os.path.join(build_dir, "index.html")
        if not os.path.isfile(index_path):
            print(f"  [!] 未找到 {index_path}，请确认路径正确")
            sys.exit(1)

    print(f"  ✓ mPython: {root}")
    print(f"  ✓ 构建目录: {build_dir}")
    print()
    print(f"  将要执行的操作:")
    print(f"    · 备份 index.html → index.html.backup")
    print(f"    · 注入 autosave.js 引用到 index.html")
    print(f"    · 复制 autosave.js 到 {build_dir}")
    print(f"    · 创建备份目录 {BACKUP_DIR}")
    print()
    confirm = input("  确认安装？(Y/n): ").strip().lower()
    if confirm == 'n':
        print("  安装已取消。")
        input("  按 Enter 键退出...")
        sys.exit(0)
    print()

    # 2. 备份原 index.html + 注入
    print("[2/4] 配置 index.html...")
    patch_index_html(index_path)
    print()

    # 3. 复制插件文件
    print("[3/4] 复制插件文件...")
    for src_rel, dest_rel in FILES_TO_COPY:
        src = os.path.join(PACKAGE_DIR, src_rel)
        dst = os.path.join(build_dir, os.path.basename(dest_rel))
        if not os.path.isfile(src):
            print(f"  [!] 缺失文件: {src}")
            continue
        try:
            shutil.copy2(src, dst)
            print(f"  ✓ {os.path.basename(dst)} → {dst}")
        except Exception as e:
            print(f"  [!] 复制失败 {src_rel}: {e}")

    print()

    # 4. 创建备份目录
    print("[4/4] 创建备份目录...")
    ensure_backup_dir()
    print()

    # 汇总
    print("=" * 56)
    print("  ✓ 安装成功！")
    print()
    print("  使用方法:")
    print("    1. 启动 mPython")
    print("    2. 顶栏出现 AutoSave v1.28 插件栏")
    print("    3. 点击 [浏览] 选择要保存的 .mxml 文件")
    print("    4. 编辑 Blockly 积木块时自动保存")
    print("    5. 备份文件存储在 D:\\mpython自动备份\\")
    print()
    print("  如需卸载，运行 uninstall.py")
    print("=" * 56)
    print()
    input("  按 Enter 键退出...")

if __name__ == "__main__":
    main()
